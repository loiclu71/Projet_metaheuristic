package isen.MetaHeuristic;

public class Position {
	

	float x;
	float y;
}
